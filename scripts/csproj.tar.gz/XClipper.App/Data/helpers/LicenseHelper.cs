﻿using System;
using System.Threading.Tasks;
using System.Net;
using System.Windows;
using System.Collections.Generic;

#nullable enable

namespace Components
{
    public class LicenseHelper : ILicense
    {
        public void Initiate(Action<Exception?> block)
        { }
    }

    [Serializable]
    public class InvalidLicenseException : Exception
    {
        public InvalidLicenseException(string message) : base(message)
        { }

        public InvalidLicenseException()
        { }

        public InvalidLicenseException(string message, Exception innerException) : base(message, innerException)
        { }

        protected InvalidLicenseException(System.Runtime.Serialization.SerializationInfo serializationInfo, System.Runtime.Serialization.StreamingContext streamingContext)
        {
            throw new NotImplementedException();
        }
    }
}
