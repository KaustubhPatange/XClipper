﻿namespace Components
{
    public static class Core
    {
        public const string CONNECTION_PASS = "";

        public static string ACTIVATION_SERVER(string v1, string f2, string v3) => "";
        public static string MIGRATION_SERVER(string v1, string v2, string v3) => "";

        public static string VALIDATION_SERVER(string v1) => "";
        public static string Encrypt(this string t) => "";
        public static string Decrypt(this string t) => "";
        public static string EncryptBase64Common(this string t) => "";
        public static bool EncryptBase64String { get; set; } = false;

        /// <summary>
        /// Used for basically encrypting clip data coming from firebase.
        /// </summary>
        /// <param name="t"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string EncryptBase64(string source, string password) => "";

        /// <summary>
        /// Used for basically decrypting clip data coming from firebase.
        /// </summary>
        /// <param name="t"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string DecryptBase64(string source, string password) => "";

        /// <summary>
        /// This will determine if the string is encrypted by the given password.
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool IsBase64Encrypted(this string t, string password)
        {
            return DecryptBase64(t, password) != null;
        }
    }
}
