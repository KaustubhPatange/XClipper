﻿using QLicense;
using System;
using System.ComponentModel;
using System.IO;

namespace Components
{
    public enum LicenseType
    {
        [Description("Premium")]
        Premium = 1,
        [Description("None")]
        Invalid = 2
    }
    
    public static class LicenseHandler
    {
        public static string UNIQUE_ID { get { return HardwareInfo.GenerateUID("XClipper"); } }
    }
}
