package com.kpstv.license

object Encryption {
    fun setPassword(password: String) {

    }

    fun getPassword() : String = ""

    fun String.Decrypt(): String = ""

    fun String.DecryptPref(): String = ""

    fun String.Encrypt(): String = ""

    fun String.EncryptPref(): String = ""
}